// Get the form element
const form = document.querySelector('form');

// Add an event listener for when the form is submitted
form.addEventListener('submit', function(event) {
  event.preventDefault();
  // Get the input values from the form
  const name = document.getElementById('registerName').value;
  const username = document.getElementById('registerUsername').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  const repeatPassword = document.getElementById('registerRepeatPassword').value;
  if(localStorage.getItem(email))
  {
    alert('user already exists.');
    return false;
  }
  // Create an object with the user's data
  const userData = {
    name: name,
    username: username,
    email: email,
    password: password,
    repeatPassword: repeatPassword
  };

  // Store the user's data in local storage
  localStorage.setItem(email, JSON.stringify(userData));
  localStorage.setItem(username, JSON.stringify(userData));
});